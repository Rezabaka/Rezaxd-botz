const fs = require('fs')
const chalk = require('chalk')
const axios = require('axios');

// OWNER BY ༄ᶦᶰᵈRezaXdツ

// TIKTOK GUA : @REZAXD_STORE
// NO WA : 085724700472

//=== Edit Disini 🔥
global.namabot = "☢️RZA×BOT☪️☢️"
global.namaowner = "༄ᶦᶰᵈRezaXdツ"
global.packname = "Sticker by"
global.creator = "ERLAN-TEAM"
global.author = "RZA×BOT\n\nSimple Bot WhatsApp"
global.wm = "༄ᶦᶰᵈRezaXdツ"
global.syt = "https://www.youtube.com/@RezaXd_store"
global.sgc = "https://chat.whatsapp.com/BhLOaPSL3SKCw9QAnudLDw"
global.idgc = "120363250058335630@g.us"
global.email = "rezhastore142@gmail.com"
global.sig = "GAKPUNYAIG"
global.myweb = ""
global.footer_text = "© RZA×BOT"
global.owner = ['6285724700472']
global.gifin = "https://telegra.ph/file/0cf1c5039a2be1b66ef15.mp4"
global.thumb = "https://telegra.ph/file/9319dc81ef3c11dbdd9bd.jpg"
global.thumb2 = "https://telegra.ph/file/c74dda31793574f84070e.jpg"
global.mark = "https://telegra.ph/file/9b67cb5ed0ff661027366.jpg"
global.themeemoji = '🌐'

//=== Introgasi 🗿
global.umurowner = "14" // Terserah🗿
global.kelasowner = "Private" // Terserah🗿
global.statusowner = "☣️Jomblo ☣️" // Terserah
global.lakiapacewek = "Cowok" // Terserah
// Kalo mau gak diisi juga gak papa

//=== Payment 😋
global.qris = "gak ada"
global.pulsa = "085724700472"
global.dana = "punya tapi lupa pin :>"
global.gopay = "085870429001"
global.rek = "gak ada rekening gua masih di bawah umur"

//=== Nokos Token 😱
global.apikey ='8c3a5b302815a138d88148fa0c5916c0595bba50' 

//=== Apikey Nya 🔥
global.lol = 'GataDios'
global.lol = 'SGWN'
global.rose = 'Rs-putangina'
global.xyro = '5dRkJDWvIG'
global.APIs = {
xyro: "https://api.xyroinee.xyz",
popcat : 'https://api.popcat.xyz'
}
// APIKeys
global.APIKeys = {
"https://api.xyroinee.xyz": "5dRkJDWvIG"
}

//=== Gak Tau 🐦
global.pairingNumber = "6285724700472"
// Nomor whatsapp bot lu
global.prefix = ['.'] 
// Jangan diubah
global.tekspushcontact = "pushkontak" 
// Terserah
global.typemenu = "v6"
// Ini type menu nya
// v1 - v2 - v3 - v4 - v5 - v6
global.typeallmenu = "v1"
// Ini type allmenu nya
// v1 - v2 - v3 - v4 - v5 - v6
global.game = true
// False (Nonaktifin)
global.groupOnly = true 
// True (Mode grup)
global.privateOnly = false
// True (Mode privat)
global.antispam = true 
// False (Nonaktifin)
global.anticall = false
// False (Nonaktifin)
global.autoreadsw = true
// False (Nonaktifin)
global.antiBot = true
// False (Nonaktifin)
global.pengingat = true
// False (Nonaktifin)
global.autoTyping = true
// False (Nonaktifin)
global.autoBio = true
// False (Nonaktifin)
global.autoRestart = true
// False (Nonaktifin)
// AutoRestart Cocok Tuk Panel Butut
global.mess = {
 done: 'Sukses!',
 wait: 'Sedang diproses',
 admin: 'ngapain ini khusus admin!',
 botNotAdmin: 'Bot jadiin grub owner bodoh',
 owner: 'ngapain Khusus Owner!',
 group: 'buat di grub bodoh!',
}

// Setting Game
global.gamewaktu = 60 // Game waktu
global.bmin = 1000 // Balance minimal 
global.bmax = 5000 // Balance maksimal
global.limit = 100 // Limit user

// Database Game
global.suit = {};
global.tictactoe = {};
global.petakbom = {};
global.kuis = {};
global.siapakahaku = {};
global.asahotak = {};
global.susunkata = {};
global.caklontong = {};
global.family100 = {};
global.tebaklirik = {};
global.tebaklagu = {};
global.tebakgambar = {};
global.tebakkimia = {};
global.tebakkata = {};
global.tebakkalimat = {};
global.tebakbendera = {};
global.tebakanime = {};
global.kuismath = {};

